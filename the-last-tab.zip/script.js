const tab = document.querySelector("#tab");
const message = document.querySelector("#message");
const hint = document.querySelector("#hint");
const counter = document.querySelector("#counter");
const status = document.querySelector("#status");
const closeButton = document.querySelector("#close");
const resetButton = document.querySelector("#reset");

let moves = 0;
let closeAttempts = 0;
let lastX = window.innerWidth / 2;
let lastY = window.innerHeight / 2;
let frozen = false;
let quietTimer;

const messages = [
  ["move your cursor around.", "it notices."],
  ["you're moving a lot.", "looking for something?"],
  ["there's nothing here.", "you can stop."],
  ["okay.", "i'm watching."],
  ["seriously.", "that's enough."]
];

function updateCounter() {
  counter.textContent = String(moves).padStart(2, "0");
}

function showMessage(index) {
  message.textContent = messages[index][0];
  hint.textContent = messages[index][1];
}

function moveTab(x, y) {
  if (frozen) return;

  const rect = tab.getBoundingClientRect();
  const tabX = rect.left + rect.width / 2;
  const tabY = rect.top + rect.height / 2;

  const dx = tabX - x;
  const dy = tabY - y;
  const distance = Math.hypot(dx, dy);

  if (distance < 190) {
    const angle = Math.atan2(dy, dx);
    const push = Math.min(95, 190 - distance);

    const moveX = Math.cos(angle) * push;
    const moveY = Math.sin(angle) * push;

    tab.style.transform = `translate(${moveX}px, ${moveY}px)`;
    document.body.classList.add("away");
    status.textContent = "it moved";

    moves++;
    updateCounter();

    if (moves === 8) showMessage(1);
    if (moves === 18) showMessage(2);
    if (moves === 30) showMessage(3);
    if (moves >= 42) showMessage(4);
  } else {
    tab.style.transform = "translate(0, 0)";
    document.body.classList.remove("away");
  }

  clearTimeout(quietTimer);
  quietTimer = setTimeout(() => {
    status.textContent = "you stopped";
    if (moves >= 18) {
      message.textContent = "you win.";
      hint.textContent = "there was nothing to win.";
    }
  }, 1800);

  lastX = x;
  lastY = y;
}

window.addEventListener("mousemove", (event) => {
  document.body.style.setProperty("--x", `${event.clientX}px`);
  document.body.style.setProperty("--y", `${event.clientY}px`);
  moveTab(event.clientX, event.clientY);
});

closeButton.addEventListener("click", () => {
  closeAttempts++;

  if (closeAttempts === 1) {
    message.textContent = "are you sure?";
    hint.textContent = "there is only one tab.";
  } else if (closeAttempts === 2) {
    message.textContent = "you really want to leave?";
    hint.textContent = "fine.";
  } else {
    frozen = true;
    tab.style.transform = "translate(0, 0) scale(.96)";
    message.textContent = "tab closed.";
    hint.textContent = "...but you opened another one.";
    status.textContent = "closed";
  }
});

resetButton.addEventListener("click", () => {
  moves = 0;
  closeAttempts = 0;
  frozen = false;
  tab.style.transform = "translate(0, 0)";
  showMessage(0);
  updateCounter();
  status.textContent = "nothing is happening";
});

updateCounter();
