# the last tab

A small interactive web toy made with plain HTML, CSS and JavaScript.

The idea is simple: the page notices where your cursor is and tries not to let you get too close.

## Run it

No installation needed.

Open `index.html` in a browser.

## Built with

- HTML
- CSS
- Vanilla JavaScript

## What I experimented with

- Cursor based interaction
- Small UI state changes
- CSS transitions
- Responsive layout
- A little browser `localStorage`-style project structure can be added later if needed
